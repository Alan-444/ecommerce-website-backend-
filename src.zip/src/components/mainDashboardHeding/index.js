import React from "react";
import styles from "./style.module.css";
import GlobalSettingIcon from "../../icons/globlSetting";
import { Link } from "react-router-dom";
import PlusIcon from "../../icons/plus";
const MainDashboardHeading = ({
	title,
	icon = true,
	icon2 = true,
	title1,
	outlineBtn,
	fillBtn,
	fillTitle,
	fillTitleTo,
	title1To,
}) => {
	return (
		<>
			<div className={styles.dw_mainTitle}>
				<h4>{title}</h4>
				{outlineBtn && (
					<div className={styles.dwmt_manag}>
						<Link to={title1To}>
							{icon ? (
								<span>
									<GlobalSettingIcon />
								</span>
							) : (
								""
							)}

							<span>{title1}</span>
						</Link>
					</div>
				)}
				{fillBtn && (
					<div className={styles.dwmt_manag2}>
						<Link to={fillTitleTo}>
							{icon2 ? (
								<span>
									<PlusIcon />
								</span>
							) : (
								""
							)}
							<span>{fillTitle}</span>
						</Link>
					</div>
				)}
			</div>
		</>
	);
};
export default MainDashboardHeading;
